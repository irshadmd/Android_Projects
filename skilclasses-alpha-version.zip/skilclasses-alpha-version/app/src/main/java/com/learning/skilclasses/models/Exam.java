package com.learning.skilclasses.models;

/**
 * Created by Mohd Arif on 17-03-2019.
 */
public class Exam {
        public String question,a,b,c,d,answer;
        public Exam() {
        }
        public Exam(String question, String a, String b, String c, String d, String answer) {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.answer = answer;
            this.question = question;
        }
    }
